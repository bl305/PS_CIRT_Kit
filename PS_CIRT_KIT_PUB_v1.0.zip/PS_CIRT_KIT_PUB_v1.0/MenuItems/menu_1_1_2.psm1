function Invoke-menu_1_1_2_action ()
{
	Write-Host -ForegroundColor Yellow -NoNewline "`nProvide 'y' for automatic resolution and 'n' to disable automatic resolution: "
	$newautomatic= Read-Host
	If (($newautomatic -ne 'q') -and ($newautomatic -ne ''))
	{
		$global:autoresolve = $newautomatic
		$log="Autoresolve='$global:autoresolve'"
		Write-AppLog $log
		Write-EvidenceLog $log
		Write-Host "Hit ENTER to refresh variables section..."
	}
}

Export-ModuleMember -Function 'Invoke-*'