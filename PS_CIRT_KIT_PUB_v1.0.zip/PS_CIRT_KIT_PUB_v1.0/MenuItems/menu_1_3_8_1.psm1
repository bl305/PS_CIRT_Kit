function Invoke-menu_1_3_8_1_action ()
{
	Foreach ($host in $global:remote_hostname_list)
	{
	
		if (Get-IsUp($host))
		{
			Write-Host -ForegroundColor DarkCyan "`nQuerying all system information: "
			$sysinfo=Get-WMIInfo($host)
			$log=($sysinfo|Format-List|Out-String)
			Write-EvidenceLog $log
			Write-Host $log
			Write-EvidenceFileCSV "test_$global:remote_hostname_list" $sysinfo
		}
		else
		{
			Write-Host -ForegroundColor Red "`nAppears to be offline, try again later...press 'ENTER' to continue"
			$log="$host Appears to be offline, try again later..."
			Write-EvidenceLog $log
		}
	}

}

Export-ModuleMember -Function 'Invoke-*'