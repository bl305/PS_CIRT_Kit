function Invoke-menu_1_1_1_action ()
{
	Write-Host -ForegroundColor Yellow -NoNewline "`nProvide evidence log file name (leave empty to cancel change): "
	$newlogfile= Read-Host
	If (($newlogfile -ne 'q') -and ($newlogfile -ne ''))
	{
		$global:evidence_log = $newlogfile
		Write-Host -ForegroundColor DarkCyan "`nEvidence log file set to '$global:evidence_log'"
		$log="Evidence Log File='$global:evidence_log'"
		Write-AppLog $log
		Write-EvidenceLog $log
		Write-Host "Hit ENTER to refresh variables section..."
	}
}

Export-ModuleMember -Function 'Invoke-*'