function Invoke-menu_1_1_4_action ()
{
	Write-Host -ForegroundColor Yellow -NoNewline "`nProvide the Local Hostname: "
	$newhost= Read-Host
	If (($newhost -ne 'q') -and ($newhost -ne ''))
	{
		$global:local_hostname  = $newhost
		$log="Local Hostname='$global:local_hostname'"
		Write-AppLog $log
		Write-EvidenceLog $log

		if ($global:autoresolve -eq "y") 
			{
				Write-Host -ForegroundColor DarkCyan "`nResolving hostname to IP"
				$global:local_ip_address=Get-IP($global:local_hostname)
				$log="Local IP Address='$global:local_ip_address'"
				Write-AppLog $log
				Write-EvidenceLog $log
			}			
		Write-Host "Hit ENTER to refresh variables section..."
	}
}

Export-ModuleMember -Function 'Invoke-*'