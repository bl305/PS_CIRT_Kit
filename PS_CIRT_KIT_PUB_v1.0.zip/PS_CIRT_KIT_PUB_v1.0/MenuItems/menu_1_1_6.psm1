function Invoke-menu_1_1_6_action ()
{
	Write-Host -ForegroundColor Yellow -NoNewline "`nProvide the Remote Hostname: "
	$newhost= Read-Host
	If (($newhost -ne 'q') -and ($newhost -ne ''))
	{
		$global:remote_hostname  = $newhost
		$global:remote_hostname_list  += $newhost
		$log="Local Hostname='$global:remote_hostname'"
		Write-AppLog $log
		Write-EvidenceLog $log
		if ($global:autoresolve -eq "y") 
			{
				Write-Host -ForegroundColor DarkCyan "`nResolving hostname to IP"
				$global:remote_ip_address=Get-IP($global:remote_hostname)
				$global:remote_ip_address_list+=$global:remote_ip_address
				$log="Remote IP Address='$global:remote_ip_address'"
				Write-AppLog $log
				Write-EvidenceLog $log
			}			
		Write-Host "Hit ENTER to refresh variables section..."
	}
}

Export-ModuleMember -Function 'Invoke-*'