function Invoke-menu_1_1_5_action ()
{
	Write-Host -ForegroundColor Yellow -NoNewline "`nProvide the Remote IP Address: "
	$newip= Read-Host
	If (($newip -ne 'q') -and ($newip -ne ''))
	{
		$global:remote_ip_address  = $newip
		$global:remote_ip_address_list  += $newip
		$log="Remote IP Address='$global:remote_ip_address'"
		Write-AppLog $log
		Write-EvidenceLog $log
		Write-Host "Hit ENTER to refresh variables section..."
		if ($global:autoresolve -eq "y") 
			{
				$newhost=Get-Hostname($newip)
				$global:remote_hostname=$newhost
				$global:remote_hostname_list+=$newip
				Write-Host -ForegroundColor DarkCyan "`nResolved $newip to $newhost"
				$log="Remote IP resolution='$newip' to '$newhost"
				Write-AppLog $log
				Write-EvidenceLog $log
			}

	}
}

Export-ModuleMember -Function 'Invoke-*'