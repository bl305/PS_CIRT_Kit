function Invoke-menu_1_1_7_action ()
{
	Write-Host -ForegroundColor Yellow -NoNewline "`nProvide the Remote IP addresses file (<full path> | if same dir <filename>): "
	$newipfile= Read-Host
	If (($newipfile -ne 'q') -and ($newipfile -ne ''))
	{
		$global:remote_ip_address  = $newipfile
		$global:remote_ip_address_list  = Get-Content -Path $newipfile
		$global:remote_hostname = $newipfile
		$log="Remote IP Address File='$global:remote_ip_address'"
		Write-AppLog $log
		Write-EvidenceLog $log
		Foreach ($ip in $global:remote_ip_address_list)
		{
			$log="Remote IP Addresses added item='$ip'"
			Write-AppLog $log
			Write-EvidenceLog $log
			Write-Host "Imported IP: $ip"
			if ($global:autoresolve -eq "y") 
				{
					$newhost=Get-Hostname($ip)
					$global:remote_hostname_list+=$ip
					Write-Host -ForegroundColor DarkCyan "`nResolved $ip to $newhost"
					$log="Remote IP resolution='$ip' to '$newhost"
					Write-AppLog $log
					Write-EvidenceLog $log
				}
			}
	}
	Write-Host "Hit ENTER to refresh variables section..."
}

Export-ModuleMember -Function 'Invoke-*'