function Invoke-menu_1_1_8_action ()
{
	Write-Host -ForegroundColor Yellow -NoNewline "`nProvide the Remote hostnames file (<full path> | if same dir <filename>): "
	$newhostfile= Read-Host
	If (($newhostfile -ne 'q') -and ($newhostfile -ne ''))
	{
		$global:remote_hostname  = $newhostfile
		$global:remote_hostname_list  = Get-Content -Path $newhostfile
		$global:remote_ip_address  = $newhostfile
		$log="Remote Hostname='$global:remote_hostname'"
		Write-AppLog $log
		Write-EvidenceLog $log
		Foreach ($host in $global:remote_hostname_list)
		{
			$log="Remote Hostname added item='$host'"
			Write-AppLog $log
			Write-EvidenceLog $log
			Write-Host "Imported hostname: $host"
			if ($global:autoresolve -eq "y") 
			{
				$newip=Get-IP($host)
				$global:remote_ip_address_list+=$host
				Write-Host -ForegroundColor DarkCyan "`nResolved $host to $newip"
				$log="Remote hostname resolution='$host' to '$newip'"
				Write-AppLog $log
				Write-EvidenceLog $log
			}
		}			
		Write-Host "Hit ENTER to refresh variables section..."
	}
}

Export-ModuleMember -Function 'Invoke-*'