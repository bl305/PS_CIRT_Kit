function Invoke-menu_1_1_3_action ()
{
	Write-Host -ForegroundColor Yellow -NoNewline "`nProvide the Local IP Address: "
	$newip= Read-Host
	If (($newip -ne 'q') -and ($newip -ne ''))
	{
		$global:local_ip_address  = $newip
		$log="Local IP Address='$global:local_ip_address'"
		Write-AppLog $log
		Write-EvidenceLog $log
		Write-Host "Hit ENTER to refresh variables section..."
	}
}

Export-ModuleMember -Function 'Invoke-*'