function Invoke-menu_1_action ()
{
	Write-Host "Main Menu"
}

Export-ModuleMember -Function 'Invoke-*'
