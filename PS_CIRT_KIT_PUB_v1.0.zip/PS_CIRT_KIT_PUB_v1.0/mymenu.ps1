#Module to import/re-import modules
Function Import-MyModule ()
{
	[cmdletbinding()]
	Param(
	[Parameter(Position=0,Mandatory=$True,HelpMessage="Enter message")][ValidateNotNullOrEmpty()][String]$amodulename
	)

	$amodulefile=".\Modules\$amodulename.psm1"
	If (Get-Module -Name $amodulename)
	{
		Write-Host "Removing module: $amodulename"
		Remove-Module $amodulename
	}
	Write-Host "Importing module: $amodulefile"
	Import-Module $amodulefile
}

#Modules necessary for operations
Import-MyModule "Mod_Pinger"
Import-MyModule "Mod_Logger"
#Required by Systeminfo menu 1.3.8.1
Import-MyModule "Mod_SystemInfo"

$programTitle="MyMenuSystem"
$global:debug=1

#$global:logging=1
$global:applogenabled=0
$global:evidencelogenabled=0
$global:evidencefilecsv=0

$now=Get-Date -Format u
$nowdate=Get-Date -Format yyyyMMdd
$nowdatestr=$nowdate.ToString()
$global:application_log='applog.txt'
$global:evidence_log="evidence_$nowdate.txt"

#Menu system definitions
$menu_1=("Configure Variables","Discover Systems","Evidence Collection","Automated Evidence Collection","Command Execution")
$menu_1_1=("CIRT PS Log file","Autoresolve IP and Host (enabled by default)","Local IP","Local Hostname","Remote IP","Remote Hostname","Remote IPs file","Remote Hostnames File","Username and password")
$menu_1_1_1=("SELECTED: "+$menu_1_1[0])
$menu_1_1_2=("SELECTED: "+$menu_1_1[1])
$menu_1_1_3=("SELECTED: "+$menu_1_1[2])
$menu_1_1_4=("SELECTED: "+$menu_1_1[3])
$menu_1_1_5=("SELECTED: "+$menu_1_1[4])
$menu_1_1_6=("SELECTED: "+$menu_1_1[5])
$menu_1_1_7=("SELECTED: "+$menu_1_1[6])
$menu_1_1_8=("SELECTED: "+$menu_1_1[7])
$menu_1_1_9=("SELECTED: "+$menu_1_1[8])
$menu_1_2=("Ping","DNS lookup")
$menu_1_2_1=("SELECTED: "+$menu_1_2[0])
$menu_1_2_2=("SELECTED: "+$menu_1_2[1])
$menu_1_3=("Devices","Files","Processes","Memory","Registry","Services","Logs","Inventory","Network")
$menu_1_3_1=("SELECTED: "+$menu_1_3[0])
$menu_1_3_2=("SELECTED: "+$menu_1_3[1])
$menu_1_3_3=("SELECTED: "+$menu_1_3[2])
$menu_1_3_4=("SELECTED: "+$menu_1_3[3])
$menu_1_3_5=("SELECTED: "+$menu_1_3[4])
$menu_1_3_6=("SELECTED: "+$menu_1_3[5])
$menu_1_3_7=("SELECTED: "+$menu_1_3[6])
$menu_1_3_8=("SELECTED: "+$menu_1_3[7])
$menu_1_3_9=("SELECTED: "+$menu_1_3[8])
$menu_1_3_1=("Disk info","Mapped drives","USB device history")
$menu_1_3_1_1=("SELECTED: "+$menu_1_3_1[0])
$menu_1_3_1_2=("SELECTED: "+$menu_1_3_1[1])
$menu_1_3_1_3=("SELECTED: "+$menu_1_3_1[2])
$menu_1_3_2=("Exists or not","File Info","Download","Check locks","Monitor changes")
$menu_1_3_2_1=("SELECTED: "+$menu_1_3_2[0])
$menu_1_3_2_2=("SELECTED: "+$menu_1_3_2[1])
$menu_1_3_2_3=("SELECTED: "+$menu_1_3_2[2])
$menu_1_3_2_4=("SELECTED: "+$menu_1_3_2[3])
$menu_1_3_2_5=("SELECTED: "+$menu_1_3_2[4])
$menu_1_3_3=("Process list")
$menu_1_3_3_1=("SELECTED: "+$menu_1_3_3[0])
$menu_1_3_4=("Create copy")
$menu_1_3_4_1=("SELECTED: "+$menu_1_3_4[0])
$menu_1_3_5=("Get registry key","Get registry extract","Change registry key")
$menu_1_3_5_1=("SELECTED: "+$menu_1_3_5[0])
$menu_1_3_5_2=("SELECTED: "+$menu_1_3_5[1])
$menu_1_3_6=("List services","Start/Stop service")
$menu_1_3_6_1=("SELECTED: "+$menu_1_3_6[0])
$menu_1_3_6_2=("SELECTED: "+$menu_1_3_6[1])
$menu_1_3_7=("Export Event logs","Search event logs","Export USN journal","Search USN journal")
$menu_1_3_7_1=("SELECTED: "+$menu_1_3_7[0])
$menu_1_3_7_2=("SELECTED: "+$menu_1_3_7[1])
$menu_1_3_7_3=("SELECTED: "+$menu_1_3_7[2])
$menu_1_3_7_4=("SELECTED: "+$menu_1_3_7[3])
$menu_1_3_8=("System Information","Installed tools","Local users","Groups","Installed applications")
$menu_1_3_8_1=("SELECTED: "+$menu_1_3_8[0])
$menu_1_3_8_2=("SELECTED: "+$menu_1_3_8[1])
$menu_1_3_8_3=("SELECTED: "+$menu_1_3_8[2])
$menu_1_3_8_4=("SELECTED: "+$menu_1_3_8[3])
$menu_1_3_8_5=("SELECTED: "+$menu_1_3_8[4])
$menu_1_3_9=("Monitor connections")
$menu_1_3_9_1=("SELECTED: "+$menu_1_3_9[0])
$menu_1_4=("Lear","Redline")
$menu_1_4_1=("SELECTED: "+$menu_1_4[0])
$menu_1_4_2=("SELECTED: "+$menu_1_4[1])
$menu_1_5=("PSEXEC","Async no wait no results","PS sync no results","PS sync with results")
$menu_1_5_1=("SELECTED: "+$menu_1_5[0])
$menu_1_5_2=("SELECTED: "+$menu_1_5[1])
$menu_1_5_3=("SELECTED: "+$menu_1_5[2])
$menu_1_5_4=("SELECTED: "+$menu_1_5[3])

#Colors for notification
$global:col_foregroundMain="Green" #cyan
$global:col_foreground="White" #darkcyan
$global:col_VariableMenu="Cyan" #green
$global:col_VariableMenuItem="Red" #Darkgreen
$global:col_Warning="Yellow" #Darkgreen

#actual menu - default 1
$global:actualmenu="1"

#environmental variables
$global:autoresolve='y'
$global:username=$env:UserName
$global:userdomain=$env:UserDomain
$global:local_hostname=$env:ComputerName
$global:local_ip_address=Get-IP($global:local_hostname)
$global:remote_ip_address="n/a"
$global:remote_ip_address_list=@()
$global:remote_hostname="n/a"
$global:remote_hostname_list=@()

Function Is-Numeric ($aValue)
{
	return $aValue -match "^[\d\.]+$"
}

Function Check-Command($acmdname)
{
    return [bool](Get-Command -Name $acmdname -ErrorAction SilentlyContinue)
}

# Variables for the menu header
Function menuvariables
{
		Write-Host -ForegroundColor $global:col_VariableMenu       "Variables"
		Write-Host -ForegroundColor $global:col_VariableMenuItem "Evidence log file`t: $global:evidence_log"
		Write-Host -ForegroundColor $global:col_VariableMenuItem "Auto DNS resolution`t: $global:autoresolve"
		Write-Host -ForegroundColor $global:col_VariableMenuItem "User`t`t`t: $global:userdomain/$global:username"
		Write-Host -ForegroundColor $global:col_VariableMenuItem "Local  IP/Hostname`t: $global:local_ip_address / $global:local_hostname"
		Write-Host -ForegroundColor $global:col_VariableMenuItem "Target IP/Hostname`t: $global:remote_ip_address / $global:remote_hostname"
}

# Call the menu system display function
Function Invoke-Menu {
	[cmdletbinding()]
	Param(
	[Parameter(Position=0,Mandatory=$True,HelpMessage="Enter your menu text")][ValidateNotNullOrEmpty()][string]$Menu,
	[Parameter(Position=1,Mandatory=$False,HelpMessage="Enter menu name")][ValidateNotNullOrEmpty()][string]$menuTitle = "Menu",
	[Alias("cls")][switch]$ClearScreen
	)

	#clear the screen if requested
	if ($ClearScreen) { 
	 Clear-Host 
	}

	Write-Host "`n`t`t $programTitle $menuTitle (selected:$global:actualmenu)`n"
	menuvariables
	Write-Host ""
#	Write-Host -ForegroundColor $global:col_foregroundMain "XMenu"

	#generating dynamic variable to pull actual menu items
	$menu_num=1
	$actualmenuname="menu_"+$Menu
#	Write-Host "Calling menu: $actualmenuname"
	$actualmenuitems=Get-Variable -Name $actualmenuname -ValueOnly -ErrorAction SilentlyContinue

	if ($actualmenuitems)
	{
		foreach ($asubmenu in $actualmenuitems)
		{
			Write-Host -ForegroundColor $global:col_foreground -NoNewline "`n["; Write-Host -NoNewline $menu_num; Write-Host -ForegroundColor $global:col_foreground -NoNewline "]"; `
			Write-Host -ForegroundColor $global:col_foreground " $asubmenu"
			$menu_num+=1
		}
		#Caling menu options, one module is one menu
		$getmodule=".\MenuItems\menu_$global:actualmenu.psm1"
#		Write-Host "getting module:"$getmodule
		Import-Module $getmodule
		$callmenu="Invoke-menu_"+$global:actualmenu+"_action"
#		Write-Host "Calling"$callmenu
		&"$callmenu"
	}
	else
	{
			Write-Host "We should not be here...$actualmenuitems:$actualmenuname"
	}

} #end function


#Menu system process:
$menu=$global:actualmenu
#Show Main menu first
Invoke-Menu -menu "1" -clear
#Then endless loop for displaying the actual menu
Do
{
	$menu=Read-Host "`nSelection ('Enter' to go back; 'q' to quit!)"
#	Write-Host "Selected menu: $menu"
#	Sleep 2
	if ($menu -eq '')
	{
#		Write-Host "Old: $global:actualmenu"
#		sleep 3
		$tmp=$global:actualmenu.split("_")
		$tmplen=$tmp.length-1
		If ($tmplen -gt 1)
		{
			$global:actualmenu=""
			for ($tmp1=0;$tmp1 -lt $tmplen;$tmp1++)
			{
				$global:actualmenu+=$tmp[$tmp1]+"_"
			}
			$global:actualmenu = $global:actualmenu -replace ".$"
		}
		else
		{
			#back to home
			$global:actualmenu="1"
		}
#		Write-Host "Menu back to: $global:actualmenu"
		Invoke-Menu -menu $global:actualmenu -clear
	}
	elseif (Is-Numeric($menu))
	{
		$newmenuname="menu_"+$global:actualmenu+"_"+$menu
		$newmenuitems=Get-Variable -Name $newmenuname -ValueOnly -ErrorAction SilentlyContinue
#		Write-Host "XXXX:"$newmenuname
		$newmenuaction="Invoke-$newmenuname"+"_action"
#		Write-Host "YYY:$newmenuaction"
#		if ($newmenuitems -and (Check-Command "Invoke-$newmenuname"))
		$newmenumodule=".\MenuItems\"+"$newmenuname"+".psm1"
		if ($newmenuitems -and (Test-Path -Path $newmenumodule))
		{
			$global:actualmenu=$global:actualmenu+"_"+$menu
#			Write-Host "Going to submenu $global:actualmenu"
#			Sleep 2
			Invoke-Menu -menu $global:actualmenu -clear
		}
		else
		{
			Write-Host -ForegroundColor $global:col_Warning "Invalid menu selected...or no ModuleItem defined!"
			sleep 2
			Invoke-Menu -menu $global:actualmenu -clear
		}
	}
	elseif ($menu -eq "q")
	{
		Write-Host "Quit..."
		sleep 2
		return
	}
	else
	{
		Write-Host "Unknown menu number...try again"
	}
} While ($True)