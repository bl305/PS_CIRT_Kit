function Write-AppLog()
{
	[cmdletbinding()]
	Param(
	[Parameter(Position=0,Mandatory=$True,HelpMessage="Enter message")][ValidateNotNullOrEmpty()][String]$amsg
	)
	If ($global:applogenabled -eq 1)
	{
		$filestr=(Get-Date -Format u)+";"+$global:local_hostname+";"+"$global:userdomain\$global:username"+";"+$amsg
		$filestr| Out-File $global:application_log -Append
	}

}

function Write-EvidenceLog()
{
	[cmdletbinding()]
	Param(
	[Parameter(Position=0,Mandatory=$True,HelpMessage="Enter message")][ValidateNotNullOrEmpty()][String]$amsg
	)
	If ($global:evidencelogenabled -eq 1)
	{
		$filestr=(Get-Date -Format u)+";$global:local_hostname;$global:remote_hostname;$global:remote_ip_address;$global:userdomain\$global:username;$amsg"
		$filestr| Out-File $global:evidence_log -Append
	}
}

function Write-EvidenceFileCSV()
{
	[cmdletbinding()]
	Param(
	[Parameter(Position=0,Mandatory=$True,HelpMessage="Enter filename")][ValidateNotNullOrEmpty()][String]$afilename,
	[Parameter(Position=1,Mandatory=$True,HelpMessage="Enter contents")]$aobject = "empty",
	[Parameter(Position=2,Mandatory=$False,HelpMessage="Enter delimiter")][string]$adelimiter = ";"	
	)
	If ($global:evidencefilecsv -eq 1)
	{
		$filestr=".\Evidences\"+$afilename+"_"+(Get-Date -Format yyyyMMddHHmmss)+".csv"
		#creating path if doesn't exist.
		$res=New-Item $filestr -Force -ItemType file
		$aobject| Export-CSV -Force -Delimiter $adelimiter -NoTypeInformation $filestr
		$alog="Evidence file written: $filestr"
		Write-EvidenceLog $alog
		Write-AppLog $alog
		Write-Host $alog
	}
}

Export-ModuleMember -Function 'Write-*'