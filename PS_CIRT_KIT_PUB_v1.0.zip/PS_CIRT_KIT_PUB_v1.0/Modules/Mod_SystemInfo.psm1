function Get-WMIInfo()
{
	[cmdletbinding()]
	Param(
	[Parameter(Position=0,Mandatory=$True,HelpMessage="Enter message")][ValidateNotNullOrEmpty()][String]$ahost
	)

	$wmi = Get-WmiObject -Class Win32_OperatingSystem -Computer $ahost|select-object *
	#$wmi = Get-WmiObject -Class Win32_OperatingSystem -Computer $ahost
	#Write-Host ($wmi|Get-Member)
	#Write-Host ($wmi|Select *)	
	#Write-Host ($wmi|Select-Object -Property *)
	#Write-Host ($wmi|Select-Object *|Format-List|Out-String)
	#Write-Host $wmi
	return $wmi
}

function Get-BasicInfo()
{
	[cmdletbinding()]
	Param(
	[Parameter(Position=0,Mandatory=$True,HelpMessage="Enter message")][ValidateNotNullOrEmpty()][String]$ahost
	)

	$wmi = Get-WmiObject -Class Win32_OperatingSystem -Computer $ahost

    $bootuptime = $wmi.ConvertToDateTime($wmi.LastBootUpTime)
	$installdate = $wmi.ConvertToDateTime($wmi.InstallDate)
    $strDiff = [DateTime]::Now - $bootuptime
	$strDiffDays=$strDiff.Days
	$strDiffHours=$strDiff.Hours
#	Write-Host "Operating System	: $wmi.Caption"
#	Write-Host "Service Pack		:$wmi.CSDVersion"
#	Write-Host "Install Date			:$installdate"
#	Write-Host "Last Boot Time		:$bootuptime"
#	Write-Host "Days since boot	:$strDiffDays,$strDiffHours"
	$OutObject = New-Object PSObject
	$OutObject | Add-Member NoteProperty 'Caption' ($wmi.Caption)
	$OutObject | Add-Member NoteProperty 'ServicePack' ($wmi.CSDVersion)
	$OutObject | Add-Member NoteProperty 'InstalledOn' ($installdate)
	$OutObject | Add-Member NoteProperty 'LastBootOn' ($bootuptime)
	$OutObject | Add-Member NoteProperty 'Days Since Boot' ("$($strDiff.Days), $($strDiff.Hours)")
	return $OutObject|Select-Object *
	#Combine Variables Option 1:
    #$OutObject = New-Object PSObject
    #$OutObject | Add-Member NoteProperty 'FQDN' ($strFQDN.HostName)
    #$OutObject | Add-Member NoteProperty 'Date' ($strDate)
    #$OutObject | Add-Member NoteProperty 'Diff' ("$($strDiff.Days), $($strDiff.Hours)")

    # # 1 A:
    # Write-Output $OutObject
    # 1 B:
    #$OutObject | Format-Table
	# 1C
	#$OutObject | export-csv output.csv
#	return $OutObject
}

Export-ModuleMember -Function 'Get-*'