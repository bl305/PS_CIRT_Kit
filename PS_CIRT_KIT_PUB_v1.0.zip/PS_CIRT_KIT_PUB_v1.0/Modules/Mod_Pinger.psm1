function Get-IP()
{
	[cmdletbinding()]
	Param(
	[Parameter(Position=0,Mandatory=$True,HelpMessage="Enter message")][ValidateNotNullOrEmpty()][String]$ahost
	)

	if (Get-IsUp($ahost))
	{
		return (Test-Connection -count 1 -Computer $ahost).IPV4Address.IPAddressToString
	}
	else
	{
		return ""
	}
}

function Get-Hostname()
{
	[cmdletbinding()]
	Param(
	[Parameter(Position=0,Mandatory=$True,HelpMessage="Enter message")][ValidateNotNullOrEmpty()][String]$aip
	)

	if (Get-IsUp($aip))
	{
		return [System.Net.Dns]::GetHostbyAddress($aip).HostName
	}
	else
	{
		return ""
	}
}


function Get-IsUp()
{
	[cmdletbinding()]
	Param(
	[Parameter(Position=0,Mandatory=$True,HelpMessage="Enter message")][ValidateNotNullOrEmpty()][String]$ahost
	)

	return Test-Connection -count 1 -quiet -Computer $ahost
}


function Get-IPQuickPing ()
{
	[cmdletbinding()]
	Param(
	[Parameter(Position=0,Mandatory=$True,HelpMessage="Enter message")][ValidateNotNullOrEmpty()][String]$ahost
	)

		$ip=""
		$Pinger = New-Object System.Net.NetworkInformation.Ping
		Try{
			$ping0=$Pinger.Send( $ahost, 500 )
			if( $ping0.Status -eq "Success" ) 
			{
				$ip=$ping0.Address.IPAddressToString
			}
			else 
			{
			#Offline?
			}
		}
		Catch {
			$ErrorMessage = $_.Exception.Message
			$FailedItem = $_.Exception.ItemName
			#write-host $ahost,$ErrorMessage,$FailedItem
		}
		Finally {
			return $ip
		}
}

#Get-WmiObject Win32_PingStatus -Filter "Address='8.8.8.8' and ResolveAddressNames='True'"

Export-ModuleMember -Function 'Get-*'